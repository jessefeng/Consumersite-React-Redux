import React from 'react';

class PageNotFound extends React.Component {

    render() {
        return (
            <h2 className="container">
                Ooops! Page Not Exist
            </h2>
        );
    }
}

export default PageNotFound;
