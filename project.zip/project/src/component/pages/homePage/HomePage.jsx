import React from 'react';

class HomePage extends React.Component {

    render() {
        return (
            <h2 className="container">
                Home Page Hero
            </h2>
        );
    }
}

export default HomePage;
