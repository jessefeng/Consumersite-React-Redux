import React from 'react';
// import PropTypes from 'prop-types';
import './style/RegistrationPage.scss';

class RegistrationPage extends React.Component {

    render() {
        return (
            <div>
                asdfasdf
            </div>
        );
    }
}

// RegistrationPage.propTypes = {
// };

export default RegistrationPage;