import App from 'Components/demo/App.jsx';
import HomePage from 'Components/pages/homePage/HomePage.jsx';
import SearchResultPage from 'Components/pages/searchResult/SearchResultPage.jsx';
import ProductDetailsPage from 'Components/pages/productDetails/ProductDetailsPage.jsx';
import RegistrationPage from 'Components/pages/registerForm/RegistrationPage.jsx';
import PageNotFound from 'Components/pages/404/PageNotFound.jsx';

const routes = {
    path: '/',
    component: App,
    indexRoute: { component: HomePage },
    childRoutes: [
        { path: 'searchresultpage', component: SearchResultPage },
        { path: 'productdetailspage(/:productID)', component: ProductDetailsPage },
        { path: 'registrationpage', component: RegistrationPage },
        { path: '*', component: PageNotFound },
    ]
};

export default routes;