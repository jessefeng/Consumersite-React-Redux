/* eslint-disable */
import 'Style/globalStyleBase.scss'
import React from 'react';
import ReactDom from 'react-dom';
import App from 'Components/demo/App.jsx';


ReactDom.render(<App />, document.getElementById('app'));

